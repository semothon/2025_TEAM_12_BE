# 2025_TEAM_12_BE

세모톤 12팀 백엔드 코드

# Contributers

- **Repository Management** : @Movingju

- **Design** : @lyksunny1214

- **Frontend** : @ParkingLot0326, @seohyunlee-coding, @moolzoo

- **Backend** : @Movingju, @scythe0425