def time_to_travel(distance_meters):
    speed_km_per_s = 2.2
    speed_m_per_s = speed_km_per_s
    time_seconds = distance_meters / speed_m_per_s
    return time_seconds
